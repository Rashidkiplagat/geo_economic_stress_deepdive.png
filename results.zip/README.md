# 🌍 Global Geo-Economic Stress Analysis (2025)

![Dashboard](geo_economic_stress_dashboard.png)

## Overview
A comprehensive analysis of economic stress across **182 countries** using
World Bank & FAOSTAT data, covering 25+ years of indicators.

## Key Findings
- 🌍 **Global average stress score: 50.3/100**
- 🔴 **Most stressed:** Eswatini (100.0), South Africa (99.5), Djibouti (98.9)
- 🟢 **Least stressed:** Qatar (0.6), Cambodia (1.1), Niger (1.6)
- 📊 **Most stressed region:** Middle East & North Africa (58.8 avg)
- 🏆 **Most stable region:** East Asia & Pacific (30.0 avg)
- 💡 Upper-middle income countries (58.5) MORE stressed than low income (43.4)
- 📈 **Biggest improver (2020–2025):** Moldova (-48.8 points)
- 📉 **Biggest decliner (2020–2025):** Guyana (+46.0 points)

## Visualisations
| Chart | Description |
|---|---|
| 🗺️ World Bubble Map | Stress by country with geographic context |
| 🔴 Top 15 Countries | Most economically stressed nations |
| 🥧 Category Distribution | Share of Low/Moderate/High/Severe stress |
| 📊 Regional Comparison | Average stress across 7 world regions |
| 💰 Income Group Analysis | Stress vs economic development level |
| 📈 Global Trend | Stress trajectory from 2000 to 2025 |
| 🔍 Score Components | What drives the final stress score |
| 🔗 Correlation Heatmap | Relationships between stress indicators |
| 📉 Improvers & Decliners | Countries with biggest 5-year changes |

## Tech Stack
- **Python** — Pandas, NumPy, Matplotlib
- **Data** — World Bank & FAOSTAT via Kaggle
- **Platform** — Kaggle Notebooks

## Dataset
[Global Geo-Economic Stress Indicators](https://www.kaggle.com/datasets/sateasinpedas/global-geo-economic-stress-indicators)

## Author
**Rashid Kiplagat** — ALX Data Science Programme
[Kaggle Profile](https://www.kaggle.com/rashidkiplagat)

---
*Analysis conducted June 2025*
